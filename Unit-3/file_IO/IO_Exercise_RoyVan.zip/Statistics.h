#ifndef STATISTICS_H
#define STATISTICS_H

float findMax(float arr[], int size);
float findMin(float arr[], int size);
float findSum(float arr[], int size);
float findAverage(float arr[], int size);
float findMedian(float arr[], int size);
void bubbleSort(float arr[], int size);

#endif
